def use_original_imbalanced(X_train_q1, X_train_q2, y_train):
    # Return the original training data without any resampling
    return X_train_q1, X_train_q2, y_train
